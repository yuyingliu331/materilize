"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var data_service_1 = require("../services/data.service");
var index_1 = require("../services/index");
var library_class_1 = require("./class/library.class");
var directory_class_1 = require("./class/directory.class");
require("rxjs/add/operator/map");
require("rxjs/Rx");
var UploadComponent = (function () {
    function UploadComponent(dataService, modalService) {
        this.dataService = dataService;
        this.modalService = modalService;
        this.selectedDir = new core_1.EventEmitter();
        this.dirLevelFolder = [];
        this.libraries = new Array();
        this.allIsChecked = false;
        this.isSubChecked = false;
    }
    UploadComponent.prototype.loadLibrary = function () {
        var _this = this;
        this.dataService.getLibraries()
            .subscribe(function (data) {
            data.map(function (library) { return _this.libraries.push(new library_class_1.default(library['Id'], library['Description'], library['PhysicalPath'])); });
        });
    };
    UploadComponent.prototype.closeModal = function (id) {
        this.currLib = null;
        this.modalService.close(id);
    };
    UploadComponent.prototype.getSubFolder = function (library) {
        var _this = this;
        this.currLib = library;
        this.currLib.directories = [];
        this.dataService.getChildLibrary(library.id, '')
            .subscribe(function (data) {
            data.map(function (dir) { return _this.currLib.directories.push(new directory_class_1.default(library.id, dir['name'], dir['relativePath'], dir['fullPath'], dir['isDirectory'], 1, null)); });
        });
        this.dirLevelFolder = [];
        this.dirLevelFolder = [this.currLib.directories];
        console.log('get librar', this.currLib.directories, this.dirLevelFolder);
    };
    UploadComponent.prototype.selectAll = function (directories) {
        var _this = this;
        this.allCheck = this.isAllSelected(directories);
        this.allCheck = !this.allCheck;
        directories.map(function (dir) {
            dir.isSelected = (_this.allCheck && !dir.isDirectory) ? true : false;
        });
    };
    UploadComponent.prototype.isAllSelected = function (childrenList) {
        var selected = false;
        childrenList.map(function (child) {
            selected = (!child.isDirectory) ? true : selected;
        });
        childrenList.map(function (child) {
            selected = (!child.isDirectory && !child.isSelected) ? false : selected;
        });
        return selected;
    };
    UploadComponent.prototype.updateSelectAll = function () {
        var _this = this;
        var currDirList = this.currLib.directories;
        this.allCheck = true;
        currDirList.map(function (curDir) {
            _this.allCheck = (!curDir.isDirectory && !curDir.isSelected) ? false : _this.allCheck;
        });
    };
    UploadComponent.prototype.selectedFolder = function ($event) {
        var lastLevel = this.dirLevelFolder.length;
        this.dirLevelFolder = this.dirLevelFolder.slice(0, $event.level);
        this.dirLevelFolder.push($event.children);
        console.log(this.dirLevelFolder);
    };
    UploadComponent.prototype.isLatestLevel = function (childrenList) {
        var isLatest = true;
        childrenList.map(function (child) {
            isLatest = child.children.length > 0 ? false : isLatest;
        });
        return isLatest;
    };
    UploadComponent.prototype.updateCurrLib = function () {
        this.currLib = null;
    };
    UploadComponent.prototype.submit = function () {
        if (this.currLib.directories) {
            var dirArr = this.currLib.directories;
            this.updatedResult = this.getSelected(dirArr, this.updatedResult);
            this.selectedDir.emit(this.updatedResult);
            console.log('final result', this.updatedResult);
        }
        this.closeModal('custom-modal-1');
        this.modalService.close('custom-modal-1');
    };
    UploadComponent.prototype.getSelected = function (dirList, resultArr) {
        for (var i = 0; i < dirList.length; i++) {
            var singleDir = dirList[i];
            if (singleDir.children.length > 0) {
                return this.getSelected(singleDir.children, resultArr);
            }
            else {
                if (singleDir.isSelected) {
                    resultArr.push(singleDir);
                }
            }
        }
        return resultArr;
    };
    UploadComponent.prototype.clearSelection = function () {
        this.updatedResult = [];
        this.selectedDir.emit(this.updatedResult);
        this.currLib = null;
    };
    UploadComponent.prototype.ngOnInit = function () {
        this.loadLibrary();
    };
    return UploadComponent;
}());
__decorate([
    core_1.Input(),
    __metadata("design:type", Object)
], UploadComponent.prototype, "updatedResult", void 0);
__decorate([
    core_1.Output(),
    __metadata("design:type", Object)
], UploadComponent.prototype, "selectedDir", void 0);
UploadComponent = __decorate([
    core_1.Component({
        selector: 'upload',
        templateUrl: 'upload.html',
        moduleId: module.id.toString()
    }),
    __metadata("design:paramtypes", [data_service_1.GetDataService, index_1.ModalService])
], UploadComponent);
exports.UploadComponent = UploadComponent;
//# sourceMappingURL=upload.component.js.map