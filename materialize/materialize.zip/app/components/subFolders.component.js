"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var directory_class_1 = require("./class/directory.class");
var data_service_1 = require("../services/data.service");
var SubFolderComponent = (function () {
    function SubFolderComponent(dataService) {
        this.dataService = dataService;
        this.selectLib = new core_1.EventEmitter();
        this.selectDir = new core_1.EventEmitter();
    }
    SubFolderComponent.prototype.loadFolders = function (dir) {
        var currentDir = dir.parentDir ? dir.parentDir.children : this.library.directories;
        currentDir.map(function (singleDir) {
            singleDir.children = [];
            singleDir.checkEnable = dir.isDirectory ? false : true;
            singleDir.isSelected = false;
        });
        this.dataService.getChildLibrary(dir.parentId, dir.path)
            .subscribe(function (data) {
            data.map(function (d) { return dir.children.push(new directory_class_1.default(dir.parentId, d['name'], d['relativePath'], d['fullPath'], d['isDirectory'], dir.level + 1, dir)); });
        });
        this.selectDir.emit(dir);
    };
    SubFolderComponent.prototype.selectAll = function (directories) {
        var _this = this;
        this.subAllSelected = this.isAllSelected(directories);
        this.subAllSelected = !this.subAllSelected;
        directories.map(function (dir) {
            dir.isSelected = (_this.subAllSelected && !dir.isDirectory) ? true : false;
        });
    };
    SubFolderComponent.prototype.isAllSelected = function (childrenList) {
        var selected = false;
        childrenList.map(function (child) {
            selected = (!child.isDirectory) ? true : selected;
        });
        childrenList.map(function (child) {
            selected = (!child.isDirectory && !child.isSelected) ? false : selected;
        });
        return selected;
    };
    SubFolderComponent.prototype.selectSingle = function (directory) {
        directory.isSelected = !directory.isSelected;
        this.selectLib.emit(directory);
    };
    SubFolderComponent.prototype.updateChildAll = function (childDir) {
        var _this = this;
        if (childDir.parentDir) {
            var currentChild = childDir.parentDir.children;
            this.subAllSelected = false;
            currentChild.map(function (oneChild) {
                _this.subAllSelected = (!oneChild.isDirectory && !oneChild.isSelected) ? false : _this.subAllSelected;
            });
        }
    };
    ;
    SubFolderComponent.prototype.isLatestLevel = function (childrenList) {
        var isLatest = true;
        childrenList.map(function (child) {
            isLatest = child.children.length > 0 ? false : isLatest;
        });
        return isLatest;
    };
    SubFolderComponent.prototype.getIcon = function (folder) {
        return folder['isDirectory'] ? 'folder' : 'file';
    };
    return SubFolderComponent;
}());
__decorate([
    core_1.Input(),
    __metadata("design:type", Object)
], SubFolderComponent.prototype, "library", void 0);
__decorate([
    core_1.Input(),
    __metadata("design:type", Object)
], SubFolderComponent.prototype, "directory", void 0);
__decorate([
    core_1.Output(),
    __metadata("design:type", Object)
], SubFolderComponent.prototype, "selectLib", void 0);
__decorate([
    core_1.Output(),
    __metadata("design:type", Object)
], SubFolderComponent.prototype, "selectDir", void 0);
SubFolderComponent = __decorate([
    core_1.Component({
        selector: 'sub-folder',
        template: "\n \n      <div class=\"clearfix folder-list\" >\n          <div *ngIf=\"directory.isDirectory === false && directory.checkEnable\" class=\"checkbox checkbox-info\">\n            <input name=\"singleSelected\" type=\"checkbox\" (click)=\"selectSingle(directory)\" [(ngModel)]=\"directory.isSelected\" [ngModelOptions]=\"{standalone: true}\">\n            <label> </label>\n          </div>\n            <i *ngIf=\"directory.isDirectory == false\" class=\"fa fa-file-video-o\" aria-hidden=\"true\"></i>\n            <i *ngIf=\"directory.isDirectory == true\" class=\"fa fa-folder-o\"></i>\n              <span class=\"folder-list-items\" (click)=\"loadFolders(directory)\">\n                {{directory.name}}\n              </span>\n          <i class=\"fa fa-angle-right pull-right\" aria-hidden=\"true\"></i>\n        </div>\n  "
    }),
    __metadata("design:paramtypes", [data_service_1.GetDataService])
], SubFolderComponent);
exports.SubFolderComponent = SubFolderComponent;
//# sourceMappingURL=subFolders.component.js.map