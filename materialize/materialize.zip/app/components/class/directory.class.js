"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Directory = (function () {
    function Directory(_parentLibId, _name, _relativePath, _fullPhysicalPath, _isDirectory, _level, _parentDir) {
        this.children = new Array();
        this.isSelected = false;
        this.checkEnable = true;
        this.name = _name;
        this.path = _relativePath;
        this.parentId = _parentLibId;
        this.fullPhysicalPath = _fullPhysicalPath;
        this.isDirectory = _isDirectory;
        this.level = _level;
        this.parentDir = _parentDir;
    }
    return Directory;
}());
exports.default = Directory;
//# sourceMappingURL=directory.class.js.map