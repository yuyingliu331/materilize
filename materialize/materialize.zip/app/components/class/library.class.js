"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Library = (function () {
    function Library(_id, _name, _path) {
        this.directories = new Array();
        this.id = _id;
        this.name = _name;
        this.path = _path;
    }
    return Library;
}());
exports.default = Library;
//# sourceMappingURL=library.class.js.map