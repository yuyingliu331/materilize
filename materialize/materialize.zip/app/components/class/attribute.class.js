"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Attribute = (function () {
    function Attribute(_name, _value) {
        this.name = '';
        this.value = '';
        this.datatype = '';
        this.isEditable = false;
        this.codeValues = new Array();
        this.name = _name;
        this.value = _value;
    }
    return Attribute;
}());
exports.Attribute = Attribute;
;
//# sourceMappingURL=attribute.class.js.map