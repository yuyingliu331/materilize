"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var core_2 = require("ng2-adal/core");
var data_service_1 = require("../services/data.service");
var attribute_class_1 = require("./class/attribute.class");
var index_1 = require("../services/index");
var HomeComponent = (function () {
    function HomeComponent(adalService, dataService, modalService, elementRef) {
        this.adalService = adalService;
        this.dataService = dataService;
        this.modalService = modalService;
        this.elementRef = elementRef;
        this.systemOfOrigins = new Array();
        this.contentTypes = new Array();
        this.priorities = new Array();
        this.workflows = new Array();
        this.archivalRules = new Array();
        this.formats = new Array();
        this.defaultSoO = '';
        this.defaultPriority = '';
        this.isRush = false;
        this.intputReason = '';
        this.name = new Array();
        this.value = new Array();
        this.attributes = new Array();
        this.codeSet = [];
        this.codeValues = [];
        this.codeSetDelta = [];
        this.templates = new Array();
        this.seletedChannels = [];
        this.selectedDirList = [];
        this.attributeResult = new Array();
        this.display = false;
        this.workflows = [{ 'name': '' }];
    }
    HomeComponent.prototype.logOut = function () {
        this.adalService.logOut();
    };
    HomeComponent.prototype.loadData = function () {
        var _this = this;
        this.dataService.getSystemOrigin()
            .subscribe(function (data) {
            _this.systemOfOrigins = data['value'];
            _this.defaultSoO = _this.systemOfOrigins[9];
        });
        this.dataService.getPriority()
            .subscribe(function (data) {
            _this.priorities = data['value'];
        });
        this.dataService.getChannel()
            .subscribe(function (data) {
            _this.channels = data['value'];
            _this.channels.map(function (cha) {
                cha.label = cha['ChannelName'];
                cha.value = cha['ChannelId'];
            });
        });
        this.dataService.getContentType()
            .subscribe(function (data) {
            _this.contentTypes = data['value'];
            _this.selectedContentType = _this.contentTypes[1];
        });
        this.dataService.getRen()
            .subscribe(function (data) {
            _this.renditions = data['value'];
            _this.renditions = _this.renditions.filter(function (ren) {
                return ren['IsDigital'] === true;
            });
            _this.renditions.map(function (ren) {
                ren.label = ren['RenditionDesc'];
                ren.value = ren['RenditionId'];
            });
        });
        this.dataService.getFormat()
            .subscribe(function (data) {
            _this.formats = data;
        });
        this.dataService.getArchivalRule()
            .subscribe(function (data) {
            _this.archivalRules = data['value'];
        });
    };
    HomeComponent.prototype.updateWorkFlowChange = function (format) {
        var _this = this;
        var formatId = format['FormatId'];
        this.dataService.getWorkFlow(formatId)
            .subscribe(function (data) {
            _this.workflows = data;
        });
    };
    HomeComponent.prototype.dirResult = function ($event) {
        this.selectedDirList = $event;
        return $event;
    };
    HomeComponent.prototype.clearSelection = function () {
        this.selectedDirList = [];
    };
    HomeComponent.prototype.deletedChannel = function (channel) {
        for (var i = 0; i < this.seletedChannels.length; i++) {
            if (channel.ChannelId === this.seletedChannels[i].ChannelId) {
                this.seletedChannels.splice(i, 1);
                break;
            }
        }
    };
    HomeComponent.prototype.openModal = function (id) {
        this.modalService.open(id);
    };
    HomeComponent.prototype.showDialog = function () {
        this.display = true;
    };
    HomeComponent.prototype.getIconName = function () {
        return 'upload';
    };
    HomeComponent.prototype.loadTemplates = function () {
        var _this = this;
        this.dataService.getTemplates()
            .subscribe(function (data) {
            _this.templates = data['value'];
        });
        this.dataService.getCodeValues()
            .subscribe(function (data) {
            _this.codeValues = data['value'];
        });
    };
    HomeComponent.prototype.getTemplate = function (templateId) {
        var tmpArr = new Array();
        this.templates.forEach(function (x) {
            if (x.AttributeTemplateId === templateId) {
                x['AttributeTemplateValue'].forEach(function (z) {
                    if (x.AttributeTemplateId === templateId) {
                        tmpArr.push(new attribute_class_1.Attribute(z.CodeSet, z.CodeValue));
                    }
                });
            }
        });
        this.attributes = tmpArr;
        this.getDelta();
    };
    HomeComponent.prototype.getCodeSets = function () {
        var _this = this;
        this.dataService.getCodeSets()
            .subscribe(function (data) {
            _this.codeSet = data['value'];
        });
    };
    HomeComponent.prototype.getDelta = function () {
        var _this = this;
        this.codeSetDelta = [];
        this.codeSet.forEach(function (x) {
            var match = false;
            _this.attributes.forEach(function (y) {
                if (x.CodeSet1 === y.name)
                    match = true;
            });
            if (!match)
                _this.codeSetDelta.push(x);
        });
        this.codeSetDelta.sort(function (a, b) {
            return (a.CodeSet1 < b.CodeSet1) ? -1 : 1;
        });
    };
    HomeComponent.prototype.editAttribute = function (attribute, index) {
        attribute.isEditable = true;
        attribute.datatype = this.codeSet.find(function (t) { return t.CodeSet1 === attribute.name; }).Datatype; // returns single obj
        var list = this.codeValues.filter(function (t) { return t.CodeSet === attribute.name; }); // returns array
        attribute.codeValues = [];
        list.forEach(function (x) {
            attribute.codeValues.push(x.CodeValueValue);
        });
        this.getDelta();
        var location = this.attributes.indexOf(attribute);
        this.attributes.map(function (att, place) { return att.isEditable = (place === index) ? true : false; });
    };
    HomeComponent.prototype.deleteAttribute = function (attName) {
        this.attributes.splice(this.attributes.indexOf(this.attributes.find(function (t) { return t.name === attName; })), 1);
    };
    HomeComponent.prototype.addAttribute = function () {
        this.getDelta();
        var att = new attribute_class_1.Attribute('', '');
        this.attributes.push(att);
        this.codeSetDelta.forEach(function (x, index) {
            if (index === 0) {
                att.name = x.CodeSet1;
                att.datatype = x.Datatype;
            }
        });
        att.isEditable = true;
        if (this.codeSetDelta.length <= 0) {
            alert('No More Attributes to add!');
        }
    };
    HomeComponent.prototype.submit = function () {
        var _this = this;
        this.attributeResult = [];
        var currentInfo = JSON.parse(sessionStorage.getItem('currentUser'));
        var userId = currentInfo.UserId;
        var userName = currentInfo.UserName;
        var userEmail = currentInfo.Email;
        var resultChannels = [];
        this.seletedChannels.map(function (data) {
            resultChannels.push((data.value).toString());
        });
        console.log(this.selectedDirList, 'selected files');
        var totalSelectedFiles = [];
        this.selectedDirList.map(function (data) {
            var eachFile = {};
            eachFile['Title'] = data.name;
            eachFile['FileName'] = data.fullPhysicalPath.replace(/%7c/g, '\\');
            totalSelectedFiles.push(eachFile);
        });
        this.attributes.map(function (attribute) {
            var obj = {};
            obj['name'] = attribute.name;
            obj['value'] = attribute.value;
            _this.attributeResult.push(obj);
        });
        // console.log('total selected files', totalSelectedFiles, (this.selectedPriority.Priority_Id).toString());
        var ingestItem = {
            'SubmittedBy': userName.toString(),
            'UserId': userId.toString(),
            'UserEmail': userEmail.toString(),
            'SystemOfOrigin': 'X',
            'ContentTypeId': (this.selectedContentType.ContentTypeId).toString(),
            'Channels': resultChannels,
            'PriorityId': (this.selectedPriority.Priority_Id).toString(),
            'RushReason': this.intputReason,
            'RenditionId': (this.renditionSelected.RenditionId).toString(),
            'FormatId': (this.formatSelected.FormatId).toString(),
            'WorkFlowId': (this.wfSelected.WorkflowTemplateId).toString(),
            'ArchivalRuleId': (this.archRuleSelect.ArchivalRuleId).toString(),
            'Attributes': this.attributeResult,
            'Files': totalSelectedFiles
        };
        console.log('ingest item', JSON.stringify(ingestItem));
        //this.dataService.submitBulkIngest(JSON.stringify(ingestItem));
    };
    // ngAfterViewInit() {
    //      this.loadData();
    //     this.getCodeSets();
    //     this.loadTemplates();
    //   var s = document.createElement("script");
    //   s.type = "text/javascript";
    //   s.src = "https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.3/js/select2.min.js";
    //   this.elementRef.nativeElement.appendChild(s);
    // }
    HomeComponent.prototype.ngOnInit = function () {
        this.loadData();
        this.getCodeSets();
        this.loadTemplates();
    };
    return HomeComponent;
}());
HomeComponent = __decorate([
    core_1.Component({
        selector: 'home',
        templateUrl: 'app/components/home.html'
    }),
    __metadata("design:paramtypes", [core_2.AdalService,
        data_service_1.GetDataService,
        index_1.ModalService,
        core_1.ElementRef])
], HomeComponent);
exports.HomeComponent = HomeComponent;
//# sourceMappingURL=home.component.js.map