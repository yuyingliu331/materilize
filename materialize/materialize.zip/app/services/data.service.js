"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var http_1 = require("@angular/http");
var Observable_1 = require("rxjs/Observable");
require("rxjs/add/operator/toPromise");
require("rxjs/add/operator/map");
require("rxjs/add/operator/catch");
require("rxjs/add/operator/filter");
var GetDataService = (function () {
    function GetDataService(http) {
        this.http = http;
        this.http = http;
    }
    GetDataService.prototype.jwt = function () {
        /** Auth settings **/
        var apiKey = 'F3A4F748-604A-4CDB-83AF-58B20FAC327B';
        var headers = new http_1.Headers();
        this.token = localStorage.getItem('id_token');
        headers.append('ApiKey', apiKey);
        headers.append('Content-Type', 'application/json');
        headers.append('Authorization', 'Bearer ' + this.token);
        var options = new http_1.RequestOptions({ headers: headers });
        return options;
    };
    GetDataService.prototype.getDevUrl = function () {
        /** staging setting **/
        return 'http://als-stg-1.mtvn.ad.viacom.com/alias/venus/';
    };
    GetDataService.prototype.getLocalUrl = function () {
        /** local settings **/
        return 'http://localhost:55200/';
    };
    GetDataService.prototype.getSystemOrigin = function () {
        return this.http.get(this.getDevUrl() + 'SystemOfOrigin', this.jwt())
            .map(function (response) { return response.json(); });
    };
    GetDataService.prototype.getPriority = function () {
        return this.http.get(this.getDevUrl() + 'Priorities', this.jwt())
            .map(function (response) { return response.json(); });
    };
    GetDataService.prototype.getContentType = function () {
        return this.http.get(this.getDevUrl() + 'ContentType', this.jwt())
            .map(function (response) { return response.json(); });
    };
    GetDataService.prototype.getChannel = function () {
        return this.http.get(this.getDevUrl() + 'Channels', this.jwt())
            .map(function (response) { return response.json(); });
    };
    GetDataService.prototype.getRen = function () {
        return this.http.get(this.getDevUrl() + 'Rendition', this.jwt())
            .map(function (data) { return data.json(); })
            .catch(function (err) { return err; });
    };
    GetDataService.prototype.getFormat = function () {
        return this.http.get(this.getDevUrl() + 'api/Formats/RenditionId?renditionId=102', this.jwt())
            .map(function (response) { return response.json(); });
    };
    GetDataService.prototype.getWorkFlow = function (formatId) {
        var serviceUrl = 'api/workflowtemplate/sourceFormat?formatID=' + formatId + "&$filter=WorkflowTemplateType eq 'Ingest' and IsActive eq true";
        return this.http.get(this.getDevUrl() + serviceUrl, this.jwt())
            .map(function (response) { return response.json(); });
    };
    GetDataService.prototype.getArchivalRule = function () {
        return this.http.get(this.getDevUrl() + 'ArchivalRules', this.jwt())
            .map(function (response) { return response.json(); });
    };
    GetDataService.prototype.getCurrentUser = function () {
        return this.http.get(this.getDevUrl() + 'api/user', this.jwt())
            .map(function (response) { return response.json(); })
            .toPromise()
            .catch(this.handleError);
    };
    GetDataService.prototype.getLibraries = function () {
        return this.http.get(this.getDevUrl() + 'api/Library?$filter=TypeId eq 5 and IsActive eq true', this.jwt())
            .map(function (response) { return response.json(); })
            .catch(this.handleError);
    };
    GetDataService.prototype.getChildLibrary = function (libraryId, relativePath) {
        return this.http.get(this.getDevUrl() + 'api/getDirectories?libraryId=' + libraryId + '&relativePath=' + relativePath + '&filter=*.*', this.jwt())
            .map(function (response) { return response.json(); })
            .catch(this.handleError);
    };
    GetDataService.prototype.getTemplates = function () {
        return this.http.get(this.getDevUrl() + 'AttributeTemplate?$filter=AttributeTemplateValue%2Fall(x1%3A%20x1%2FItemType%20eq%20%27Content%27)&$orderby=AttributeTemplateDesc&$expand=AttributeTemplateValue', this.jwt())
            .map(function (response) { return response.json(); });
    };
    GetDataService.prototype.getCodeSets = function () {
        return this.http.get(this.getDevUrl() + "CodeSets?$filter=((ActiveInd%20eq%20true)%20and%20(Level%20eq%20'Content'))%20and%20(Usage%20eq%20'Tech%20Attributes')&$orderby=CodeSet1", this.jwt())
            .map(function (response) { return response.json(); });
    };
    GetDataService.prototype.getCodeValues = function () {
        return this.http.get(this.getDevUrl() + 'CodeValues?$orderby=CodeValueValue', this.jwt())
            .map(function (response) { return response.json(); });
    };
    GetDataService.prototype.submitBulkIngest = function (ingestItem) {
        return this.http.post(this.getDevUrl() + 'api/SubmitBulkIngest', ingestItem, this.jwt())
            .map(function (response) { return response.json(); })
            .catch(this.handleError);
    };
    GetDataService.prototype.handleError = function (error) {
        // In a real world app, you might use a remote logging infrastructure
        var errMsg;
        if (error instanceof Response) {
            var body = error.json() || '';
            var err = JSON.stringify(body);
            errMsg = error.status + " - " + (error.statusText || '') + " " + err;
        }
        else {
            errMsg = error.message ? error.message : error.toString();
        }
        console.error(errMsg);
        return Observable_1.Observable.throw(errMsg);
    };
    return GetDataService;
}());
GetDataService = __decorate([
    core_1.Injectable(),
    __metadata("design:paramtypes", [http_1.Http])
], GetDataService);
exports.GetDataService = GetDataService;
//# sourceMappingURL=data.service.js.map