"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var router_1 = require("@angular/router");
var core_2 = require("ng2-adal/core");
var data_service_1 = require("../services/data.service");
var LoggedInGuard = (function () {
    function LoggedInGuard(adalService, router, dataService) {
        this.adalService = adalService;
        this.router = router;
        this.dataService = dataService;
    }
    LoggedInGuard.prototype.canActivate = function () {
        if (this.adalService.userInfo.isAuthenticated) {
            var appIdUri = 'https://viacom.onmicrosoft.com/vmsapidev';
            var token_1;
            this.adalService.acquireToken(appIdUri).subscribe(function (p) {
                token_1 = p;
                localStorage.setItem('id_token', token_1);
            });
            var currentUser_1;
            this.dataService.getCurrentUser()
                .then(function (data) {
                currentUser_1 = JSON.stringify(data);
                sessionStorage.setItem('currentUser', currentUser_1);
            });
            return true;
        }
        else {
            this.router.navigate(['/welcome']);
            return false;
        }
    };
    return LoggedInGuard;
}());
LoggedInGuard = __decorate([
    core_1.Injectable(),
    __metadata("design:paramtypes", [core_2.AdalService,
        router_1.Router, data_service_1.GetDataService])
], LoggedInGuard);
exports.LoggedInGuard = LoggedInGuard;
//# sourceMappingURL=logged-in.guard.js.map