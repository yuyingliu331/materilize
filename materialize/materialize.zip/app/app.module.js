"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var platform_browser_1 = require("@angular/platform-browser");
var forms_1 = require("@angular/forms");
var core_2 = require("ng2-adal/core");
var angular2_fontawesome_1 = require("angular2-fontawesome/angular2-fontawesome");
var http_1 = require("@angular/http");
var app_component_1 = require("./components/app.component");
var app_router_1 = require("./routers/app.router");
var welcome_component_1 = require("./components/welcome.component");
var home_component_1 = require("./components/home.component");
var upload_component_1 = require("./components/upload.component");
var subFolders_component_1 = require("./components/subFolders.component");
var logged_in_guard_1 = require("./authentication/logged-in.guard");
var secret_service_1 = require("./services/secret.service");
var data_service_1 = require("./services/data.service");
var primeng_1 = require("primeng/primeng");
var primeng_2 = require("primeng/primeng");
var primeng_3 = require("primeng/primeng");
var index_1 = require("./directives/index");
var index_2 = require("./services/index");
var ngx_tooltip_1 = require("ngx-tooltip");
var AppModule = (function () {
    function AppModule() {
    }
    return AppModule;
}());
AppModule = __decorate([
    core_1.NgModule({
        imports: [platform_browser_1.BrowserModule, app_router_1.routes, forms_1.FormsModule, http_1.HttpModule, angular2_fontawesome_1.Angular2FontawesomeModule, ngx_tooltip_1.TooltipModule, primeng_1.MultiSelectModule, primeng_2.DropdownModule, primeng_3.DialogModule],
        declarations: [app_component_1.AppComponent, home_component_1.HomeComponent, welcome_component_1.WelcomeComponent, index_1.ModalComponent, upload_component_1.UploadComponent, subFolders_component_1.SubFolderComponent],
        providers: [core_2.AdalService, secret_service_1.SecretService, logged_in_guard_1.LoggedInGuard, data_service_1.GetDataService, index_2.ModalService],
        bootstrap: [app_component_1.AppComponent],
    })
], AppModule);
exports.AppModule = AppModule;
//# sourceMappingURL=app.module.js.map